﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PI_Web.Controllers
{
    public class ItemController : Controller
    {
        // GET: Item
        public ActionResult Item1()
        {
            return View();
        }
        public ActionResult Item2()
        {
            return View();
        }
        public ActionResult Item3()
        {
            return View();
        }
        public ActionResult Item4()
        {
            return View();
        }
        public ActionResult Item5()
        {
            return View();
        }
        public ActionResult Item6()
        {
            return View();
        }
        public ActionResult Item7()
        {
            return View();
        }
        public ActionResult Item8()
        {
            return View();
        }
        public ActionResult Item9()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetData(int index)
        {
            var fileDir = Server.MapPath("~/ItemData");
            if (!Directory.Exists(fileDir))
                Directory.CreateDirectory(fileDir);

            var filePath = Path.Combine(fileDir, $"Item{index}.txt");
            if (System.IO.File.Exists(filePath))
            {
                return Json(System.IO.File.ReadAllLines(filePath), JsonRequestBehavior.AllowGet);
            }
            else
                return null;
        }

        [HttpPost]
        public JsonResult SaveData(int index, string[] items)
        {
            var fileDir = Server.MapPath("~/ItemData");
            if (!Directory.Exists(fileDir))
                Directory.CreateDirectory(fileDir);

            var filePath = Path.Combine(fileDir, $"Item{index}.txt");

            System.IO.File.WriteAllLines(filePath, items);

            return Json(true);
        }
    }
}