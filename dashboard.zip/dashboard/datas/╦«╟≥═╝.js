// 水球内部数据--蓝色
var value = 0.32;
// 水球颞部数据--灰色
var value3 = 76
var value1 = 75.2
var value2 = 75.2

var data = [value, value, value];

var option = {
    // 圆环内部文字
    title: [
        {
            text: 'L/双',
            left: '50%',
            top: "50%",
            textAlign: 'center',
            textStyle: {
                fontSize: '30',
                color: '#8492A6',

                textAlign: 'center',
            },
        },
        {
            text: 30,
            left: '50%',
            top: '40%',
            textAlign: 'center',
            textStyle: {
                fontSize: 60,
                color: '#1B86E9',
            },
        },
        
    ],
    series: [{
        type: 'liquidFill',
        radius: '50%',
        z: 6,
        center: ['50%', '50%'],
        amplitude: 20,
        backgroundStyle: {
            color: {
                type: 'radial',
                x: 0.5,
                y: 0.5,
                r: 0.5,
                colorStops: [
                    {
                        offset: 0,
                        color: '#E0EEFC',
                    },
                    {
                        offset: 0.75,
                        color: '#D4E8FA',
                    },
                    {
                        offset: 1,
                        color: '#B1D6F9',
                    },
                ],
                globalCoord: false,
            },
        },
        color: [
            {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                    {
                        offset: 1,
                        color: '#6CDEFC',
                    },
                    {
                        offset: 0,
                        color: '#429BF7',
                    },
                ],
                globalCoord: false,
            },
            {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                    {
                        offset: 1,
                        color: '#6CDEFC',
                    },
                    {
                        offset: 0,
                        color: '#429BF7',
                    },
                ],
                globalCoord: false,
            },
            {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                    {
                        offset: 1,
                        color: '#A7CAFD',
                    },
                    {
                        offset: 0,
                        color: '#449CEC',
                    },
                ],
                globalCoord: false,
            },
        ],
        data: [value + 0.02,
        {
            value: value - 0.01,
            direction: 'left',
        },
        value - 0.01,
        ],
        label: {
            normal: {
                formatter: '',
            }
        },
        outline: {
            show: true,
            itemStyle: {
                borderWidth: 0,
            },
            borderDistance: 0,
        }
    },
    {
        //外发光
        type: 'pie',
        z: 1,
        zlevel: -1,
        radius: ['50%', '52%'],
        center: ['50%', '50%'],
        hoverAnimation: false,
        clockWise: false,
        itemStyle: {
            normal: {
                borderWidth: 20,
                color: '#DEEDFB',
            },
        },
        label: {
            show: false,
        },
        data: [100],
    },
    ]
}