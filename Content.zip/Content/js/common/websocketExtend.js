﻿
let _ws;

const ws = {
    connect: (url) => {
        _ws = new WebSocket(url);
        return _ws;
    },
    pong: () => {

    },
    sendMessage: () => {
        if (_ws.readyState === 1) {
            vm.$message.warning('WebSocket连接已关闭', 1);
            return;
        }
    }
}